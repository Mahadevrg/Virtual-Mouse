from aliases.base import run_setup


run_setup("to-requirements.txt")
