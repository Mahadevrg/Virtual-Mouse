from requirements_txt.commands import cli

if __name__ == "__main__":
    cli()
