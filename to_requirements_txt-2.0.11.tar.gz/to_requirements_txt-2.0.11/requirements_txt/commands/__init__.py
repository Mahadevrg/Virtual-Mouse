import requirements_txt.commands.config.command  # noqa: F401
import requirements_txt.commands.init.command  # noqa: F401
import requirements_txt.commands.install.command  # noqa: F401
import requirements_txt.commands.show.command  # noqa: F401
from requirements_txt.commands.cli import cli  # noqa: F401
